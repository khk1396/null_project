package com.kh.semibox.boxopen.model;

import java.io.*;
import java.net.HttpURLConnection;
import java.net.URL;

public class Fortune {

    private static final String OPENAI_API_KEY = "API-KEY"; 
    private static final String OPENAI_API_URL = "https://api.openai.com/v1/chat/completions";
    private static final String MODEL_NAME = "gpt-3.5-turbo";
    private static final double TEMPERATURE = 0.2;
    private static final int MAX_TOKEN = 50;

    public static String getFortune() {
        return getFortuneFromOpenAI("오늘의 운세를 2줄로 알려줘.");
    }

    private static String getFortuneFromOpenAI(String prompt) {
	    int retryCount = 0;
	    while (retryCount < 3) {  // 최대 3번 재시도
	        try {
	            URL url = new URL(OPENAI_API_URL);
	            HttpURLConnection connection = (HttpURLConnection) url.openConnection();
	            connection.setRequestMethod("POST");
	            connection.setRequestProperty("Content-Type", "application/json");
	            connection.setRequestProperty("Authorization", "Bearer " + OPENAI_API_KEY);
	            connection.setDoOutput(true);

	            String requestBody = "{"
	                    + "\"model\": \"" + MODEL_NAME + "\","
	                    + "\"messages\": [{\"role\": \"user\", \"content\": \"" + prompt + "\"}],"
	                    + "\"temperature\": " + TEMPERATURE + ","
	                    + "\"max_tokens\": " + MAX_TOKEN
	                    + "}";

	            try (OutputStream os = connection.getOutputStream()) {
	                os.write(requestBody.getBytes("utf-8"));
	            }

	            int responseCode = connection.getResponseCode();
	            if (responseCode == HttpURLConnection.HTTP_OK) {
	                BufferedReader in = new BufferedReader(new InputStreamReader(connection.getInputStream(), "utf-8"));
	                StringBuilder response = new StringBuilder();
	                String line;
	                while ((line = in.readLine()) != null) {
	                    response.append(line);
	                }
	                in.close();
	                return extractFortune(response.toString());
	            } else if (responseCode == 429) {
	                // 429 오류가 발생하면 잠시 대기 후 재시도
	                retryCount++;
	                Thread.sleep(1000 * retryCount);  // 재시도할 때마다 대기 시간 증가 (예: 1초, 2초, 3초)
	            } else {
	                return "[API 요청 실패: 응답 코드 " + responseCode + "]";
	            }
	        } catch (Exception e) {
	            return "[오류] " + e.getMessage();
	        }
	    }
	    return "[금일 운세 : 좋음]";
	}

    // JSON 없이 응답에서 운세 추출
    private static String extractFortune(String response) {
        String key = "\"content\":\"";
        int startIndex = response.indexOf(key);
        if (startIndex == -1) return "운세 추출 실패";

        startIndex += key.length();
        int endIndex = response.indexOf("\"", startIndex);
        if (endIndex == -1) return "운세 추출 실패";

        return response.substring(startIndex, endIndex).trim();
    }
}
